export interface LibroCrear{
    titulo: string,
    autor: string,
    fechapublicacion: string,
}
export interface Libro{
    id: number,
    titulo: string,
    autor: string,
    fechapublicacion: string,
}