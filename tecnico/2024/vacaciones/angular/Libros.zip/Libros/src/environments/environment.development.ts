export const environment = {
    url: 'https://localhost:7009',
};
