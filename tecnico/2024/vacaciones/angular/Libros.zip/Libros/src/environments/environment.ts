export const environment = {
    url: 'PENDIENTE',

};
